package com.example.ads_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
