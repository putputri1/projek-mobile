import 'package:ads_test/features/cartpage/widget/cart_item_widget.dart';
import 'package:ads_test/features/cartpage/widget/summary_widget.dart';
import 'package:ads_test/features/checkout/view/checkout_main_page.dart';
import 'package:ads_test/utils/app_color.dart';
import 'package:ads_test/utils/app_textstyle.dart';
import 'package:ads_test/widgets/custom_appbar.dart';
import 'package:ads_test/widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

class CartPageMain extends StatelessWidget {
  const CartPageMain({super.key});

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Get.back();
        return false;
      },
      child: Scaffold(
        appBar: CustomAppBar.defaultAppBar(title: 'Keranjang'),
        body: Padding(
          padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 2.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // head
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '2 Items in your cart',
                        style: greyTextStyle.copyWith(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          onPressed: () {},
                          icon: Icon(Icons.add, color: greenColor),
                          label: Text(
                            "Tambah Item",
                            style: greenTextStyle.copyWith(fontSize: 16.sp),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 1.h),
                  // cart item
                  Column(
                    children: List.generate(
                      2,
                      (index) {
                        return Column(
                          children: [
                            CartItemWidget(
                              image: "assets/images/diet_product_example2.png",
                              title: "Sugar free gold",
                              desc: "bottle of 500 pellets",
                              price: "Rp 25.000",
                            ),
                            SizedBox(height: 0.5.h),
                            Divider(color: greyColor.withOpacity(0.3)),
                          ],
                        );
                      },
                    ),
                  ),

                  SizedBox(height: 4.h),
                  Text(
                    "Ringkasan Pesanan",
                    style: blackTextStyle.copyWith(
                      fontSize: 18.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 1.5.h),
                  SummaryWidget(),
                ],
              ),
              Column(
                children: [
                  CustomButton(
                    elevation: 8,
                    width: MediaQuery.of(context).size.width,
                    height: 6.h,
                    borderColor: primaryColor,
                    borderWidth: 0,
                    textStyle: whiteTextStyle.copyWith(
                        fontSize: 16.sp, fontWeight: FontWeight.w700),
                    text: 'Place Order @ Rp 185.000',
                    onPressed: () {
                      Get.to(() => const CheckoutMainPage());
                    },
                    backgroundColor: primaryColor,
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}

class CouponWidget extends StatelessWidget {
  const CouponWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 8.h,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        border: Border.all(
          color: blackColor.withOpacity(0.1),
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 5.w),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Icon(
                  Icons.discount_outlined,
                  color: blackColor,
                ),
                SizedBox(width: 2.w),
                Text(
                  "1 Coupon applied",
                  style: greenTextStyle.copyWith(fontSize: 14.sp),
                )
              ],
            ),
            IconButton(
                onPressed: () {}, icon: const Icon(Icons.cancel_outlined))
          ],
        ),
      ),
    );
  }
}
