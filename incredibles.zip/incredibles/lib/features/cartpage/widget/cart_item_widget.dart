import 'package:ads_test/utils/app_color.dart';
import 'package:ads_test/utils/app_textstyle.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class CartItemWidget extends StatelessWidget {
  const CartItemWidget(
      {super.key,
      required this.title,
      required this.image,
      required this.desc,
      required this.price});

  final String title;
  final String image;
  final String desc;
  final String price;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          height: 12.h,
          width: 20.w,
          decoration: BoxDecoration(
            border: Border.all(color: blackColor),
            borderRadius: BorderRadius.circular(10),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.asset(
              // 'assets/images/diet_product_example2.png',
              image,
              fit: BoxFit.cover,
            ),
          ),
        ),
        // item
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: blackTextStyle.copyWith(fontSize: 17.sp),
            ),
            Text(
              desc,
              style: greyTextStyle.copyWith(
                fontSize: 14.sp,
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              price,
              style: blackBoldTextStyle.copyWith(
                fontSize: 16.sp,
              ),
            )
          ],
        ),

        Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            IconButton(
              // alignment: Alignment.topRight,
              onPressed: () {},
              icon: Icon(
                Icons.cancel_outlined,
                color: redColor,
              ),
            ),
            SizedBox(height: 2.h),
            // Spacer(),
            Padding(
              padding: EdgeInsets.only(right: 2.w),
              child: Container(
                height: 5.h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  color: whiteColor,
                ),
                // padding: EdgeInsets.symmetric(horizontal: 1.5.w, vertical: 1.h),
                width: 25.w,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: () {},
                      child: Icon(
                        Icons.add_circle_rounded,
                        size: 25.sp,
                        color: greenColor,
                      ),
                    ),
                    Text("1"),
                    GestureDetector(
                      onTap: () {},
                      child: Icon(
                        Icons.remove_circle,
                        size: 25.sp,
                        color: primaryColor,
                      ),
                    ),
                  ],
                ),
              ),
            )
            // SizedBox(height: 2.5.h),
            // const CustomCounter(),
          ],
        )
      ],
    );
  }
}

// SizedBox(height: 1.5.h),
// Divider(),
