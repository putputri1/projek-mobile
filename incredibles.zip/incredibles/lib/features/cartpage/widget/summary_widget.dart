import 'package:ads_test/utils/app_color.dart';
import 'package:ads_test/utils/app_textstyle.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class SummaryWidget extends StatelessWidget {
  const SummaryWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text("Order Total", style: greyTextStyle.copyWith(fontSize: 15.sp)),
            Text("Rp 228.800", style: blackTextStyle.copyWith(fontSize: 16.sp)),
          ],
        ),
        SizedBox(height: 1.h),
        // Row(
        //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //   children: [
        //     Text("Items Discount",
        //         style: greyTextStyle.copyWith(fontSize: 14.sp)),
        //     Text("- Rp 28.800",
        //         style: blackTextStyle.copyWith(fontSize: 14.sp)),
        //   ],
        // ),
        // SizedBox(height: 1.5.h),
        // Row(
        //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //   children: [
        //     Text("Coupon Discount",
        //         style: greyTextStyle.copyWith(fontSize: 14.sp)),
        //     Text("- Rp 15.800",
        //         style: blackTextStyle.copyWith(fontSize: 14.sp)),
        //   ],
        // ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text("Shipping", style: greyTextStyle.copyWith(fontSize: 15.sp)),
            Text("Free", style: blackTextStyle.copyWith(fontSize: 16.sp)),
          ],
        ),
        SizedBox(height: 3.h),
        Divider(
          color: greyColor.withOpacity(0.3),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text("Total", style: blackTextStyle.copyWith(fontSize: 15.sp)),
            Text("Rp 185.000",
                style: blackBoldTextStyle.copyWith(fontSize: 16.sp)),
          ],
        ),
      ],
    );
  }
}
