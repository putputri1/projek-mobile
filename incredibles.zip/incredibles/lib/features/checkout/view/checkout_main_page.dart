import 'package:ads_test/features/checkout/widget/address_card.dart';
import 'package:ads_test/features/checkout/widget/custom_box_card.dart';
import 'package:ads_test/utils/app_color.dart';
import 'package:ads_test/utils/app_textstyle.dart';
import 'package:ads_test/utils/success_screen.dart';
import 'package:ads_test/widgets/custom_appbar.dart';
import 'package:ads_test/widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

class CheckoutMainPage extends StatelessWidget {
  const CheckoutMainPage({super.key});

  @override
  Widget build(BuildContext context) {
    final RxInt selectedAddress = (-1).obs;
    final RxInt selectedPayment = (-1).obs;
    return Scaffold(
      appBar: CustomAppBar.defaultAppBar(title: 'Checkout'),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 2.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '2 Items in your cart',
                    style: greyTextStyle.copyWith(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        "TOTAL",
                        style: primaryTextStyle.copyWith(fontSize: 17.sp),
                      ),
                      Text(
                        "Rp 185.000",
                        style: primaryBoldTextStyle.copyWith(fontSize: 17.sp),
                      ),
                    ],
                  ),
                  // alamat pengiriman
                ],
              ),
              SizedBox(height: 2.h),
              Text(
                "Alamat Pengiriman",
                style: blackTextStyle.copyWith(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 1.h),
              Column(
                  children: List.generate(
                2,
                (index) {
                  return Padding(
                    padding: EdgeInsets.only(bottom: 1.h),
                    child: Obx(
                      () => AddressCard(
                        type: "Home",
                        phone: "081234567890",
                        address: "Jl. Rajawali No. 02, Surabaya",
                        isActive: selectedAddress.value == index,
                        onEditTap: () {},
                        onPressed: () {
                          if (selectedAddress.value == index) {
                            selectedAddress.value = -1;
                          } else {
                            selectedAddress.value = index;
                          }
                        },
                      ),
                    ),
                  );
                },
              )),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: () {},
                  icon: Icon(Icons.add, color: greenColor),
                  label: Text(
                    "Tambah Alamat",
                    style: greenTextStyle.copyWith(fontSize: 16.sp),
                  ),
                ),
              ),
              Text(
                "Metode Pembayaran",
                style: blackTextStyle.copyWith(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 1.5.h),
              CustomBoxCard(
                height: 9.h * 3,
                child: Column(
                  children: List.generate(3, (index) {
                    return Obx(
                      () => ListTile(
                        contentPadding: EdgeInsets.zero,
                        onTap: () {
                          if (selectedPayment.value == index) {
                            selectedPayment.value = -1;
                          } else {
                            selectedPayment.value = index;
                          }
                        },
                        leading: Icon(Icons.account_balance),
                        title: Text("Bank Transfer"),
                        trailing: selectedPayment.value == index
                            ? Icon(Icons.radio_button_checked,
                                color: greenColor)
                            : Icon(Icons.radio_button_unchecked),
                      ),
                    );
                  }),
                ),
              ),
              // Spacer(),
              SizedBox(height: 1.8.h),
              CustomButton(
                elevation: 8,
                width: MediaQuery.of(context).size.width,
                height: 6.h,
                borderColor: primaryColor,
                borderWidth: 0,
                textStyle: whiteTextStyle.copyWith(
                    fontSize: 16.sp, fontWeight: FontWeight.w700),
                text: 'Bayar Sekarang',
                onPressed: () {
                  Get.to(
                    () => SuccessScreen(
                      invoice: "#INV20240817",
                    ),
                  );
                },
                backgroundColor: primaryColor,
              )
            ],
          ),
        ),
      ),
    );
  }
}
