import 'package:ads_test/features/checkout/widget/custom_box_card.dart';
import 'package:ads_test/utils/app_color.dart';
import 'package:ads_test/utils/app_textstyle.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class AddressCard extends StatelessWidget {
  const AddressCard({
    super.key,
    required this.type,
    required this.phone,
    required this.address,
    this.isActive = false,
    this.onPressed,
    this.onEditTap,
  });

  final String type;
  final String phone;
  final String address;
  final bool isActive;
  final Function()? onPressed;
  final Function()? onEditTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: CustomBoxCard(
        isActive: isActive,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  isActive
                      ? Icons.radio_button_checked
                      : Icons.radio_button_unchecked,
                  color: isActive ? greenColor : greyColor,
                ),
                SizedBox(width: 3.w),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      type,
                      // "Home",
                      style: blackBoldTextStyle.copyWith(
                          fontSize: 16.sp, fontWeight: FontWeight.w800),
                    ),
                    Text(
                      phone,
                      // "08123467890",
                      style: greyTextStyle.copyWith(fontSize: 16.sp),
                    ),
                    Text(
                      address,
                      // "Jl. Rajawali No. 02, Surabaya",
                      style: greyTextStyle.copyWith(fontSize: 16.sp),
                    )
                  ],
                ),
              ],
            ),
            IconButton(
              onPressed: onEditTap,
              icon: Icon(
                Icons.border_color_outlined,
                color: greyColor,
              ),
            )
          ],
        ),
      ),
    );
  }
}
