import 'package:ads_test/utils/app_color.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

/// [isActive] parameter boolean
class CustomBoxCard extends StatelessWidget {
  const CustomBoxCard({
    super.key,
    required this.child,
    this.isActive = false,
    this.height,
    this.width,
    this.padding,
  });

  final Widget child;
  final bool isActive;
  final double? height;
  final double? width;
  final EdgeInsetsGeometry? padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding:
          padding ?? EdgeInsets.symmetric(vertical: 2.6.h, horizontal: 5.w),
      height: height ?? 13.h,
      width: width ?? MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
            color: isActive ? greenColor : greyColor, width: isActive ? 2 : 1),
      ),
      child: child,
    );
  }
}
