import 'package:ads_test/features/cartpage/view/cart_page_main.dart';
import 'package:ads_test/features/diabetes_care/widget/banner_slider_product.dart';
import 'package:ads_test/features/home/view/homescreen.dart';
import 'package:ads_test/utils/app_color.dart';
import 'package:ads_test/utils/app_constant.dart';
import 'package:ads_test/utils/app_textstyle.dart';
import 'package:ads_test/widgets/custom_appbar.dart';
import 'package:ads_test/widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

class DetailProduct extends StatelessWidget {
  const DetailProduct({super.key});

  @override
  Widget build(BuildContext context) {
    final isActive = false.obs;
    return Scaffold(
      appBar: CustomAppBar.defaultAppBar(actions: [
        IconButton(
          onPressed: () {},
          icon: Icon(
            Icons.shopping_bag_outlined,
            size: 3.5.h,
          ),
        ),
      ]),
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 2.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Sugar Free Gold Low ",
                        style: blackBoldTextStyle.copyWith(
                          fontSize: 20.sp,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        "Etiam mollis metus non purus ",
                        style: greyTextStyle.copyWith(fontSize: 16.sp),
                      ),
                      SizedBox(height: 2.h),
                      const BannerSliderProduct(),
                      SizedBox(height: 2.h),
                      const MainContentDetailProduct(),
                      SizedBox(height: 2.h),
                    ],
                  ),
                  CustomButton(
                    elevation: 8,
                    width: MediaQuery.of(context).size.width,
                    height: 6.h,
                    borderColor: primaryColor,
                    borderWidth: 0,
                    textStyle: whiteTextStyle.copyWith(
                        fontSize: 16.sp, fontWeight: FontWeight.w700),
                    text: 'Add To Cart'.toUpperCase(),
                    onPressed: () {
                      isActive.value = true;
                    },
                    backgroundColor: primaryColor,
                  ),
                ],
              ),
            ),
          ),
          Obx(
            () => Visibility(
              visible: isActive.value,
              child: DialogSuccess(),
            ),
          )
        ],
      ),
    );
  }
}

class MainContentDetailProduct extends StatelessWidget {
  const MainContentDetailProduct({super.key});

  @override
  Widget build(BuildContext context) {
    final RxInt activeIndex = (-1).obs;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Rp 56.000",
                  style: blackBoldTextStyle.copyWith(
                    fontSize: 18.sp,
                  ),
                ),
                Text(
                  "Etiam mollis ",
                  style: greyTextStyle.copyWith(
                    fontSize: 14.sp,
                  ),
                )
              ],
            ),
          ],
        ),
        SizedBox(height: 1.h),
        const Divider(),
        SizedBox(height: 1.h),
        Text(
          "Package Size",
          style: blackTextStyle.copyWith(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.5.h),
        Row(
          children: List.generate(3, (index) {
            return GestureDetector(
                onTap: () {
                  if (activeIndex.value == index) {
                    activeIndex.value = -1;
                  } else {
                    activeIndex.value = index;
                  }
                },
                child: Obx(
                  () => Padding(
                    padding: EdgeInsets.only(left: 1.w, right: 1.w),
                    child: packageContainerWidget(
                        activeIndex.value == index, "1 Kg"),
                  ),
                ));
          }),
        ),
        SizedBox(height: 3.h),
        Text(
          "Product Details",
          style: blackTextStyle.copyWith(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.5.h),
        Text(
          "Interdum et malesuada fames ac ante ipsum primis in faucibus. Morbi ut nisi odio. Nulla facilisi. Nunc risus massa, gravida id egestas a, pretium vel tellus. Praesent feugiat diam sit amet pulvinar finibus. Etiam et nisi aliquet, accumsan nisi sit.",
          style: greyTextStyle.copyWith(fontSize: 14.sp),
          textAlign: TextAlign.justify,
        ),
        SizedBox(height: 5.h),
      ],
    );
  }
}

class DialogSuccess extends StatelessWidget {
  const DialogSuccess({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: blackColor.withOpacity(0.5),
      body: Center(
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            color: whiteColor,
          ),
          height: 50.h,
          width: 60.w,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 5.h),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Image.asset(
                  AppConstant.successIcon,
                  width: 50.w,
                ),
                SizedBox(height: 3.h),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      "BERHASIL",
                      style: primaryBoldTextStyle.copyWith(fontSize: 18.sp),
                    ),
                    Text(
                      "Berhasil menambahkan barang ke keranjang.",
                      textAlign: TextAlign.center,
                      style: greyTextStyle.copyWith(fontSize: 14.sp),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        TextButton(
                          onPressed: () {
                            Get.back();
                            Get.to(() => CartPageMain(),
                                preventDuplicates: false);
                          },
                          child: Text(
                            "Go To Cart",
                            style: greenBoldTextStyle,
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            Get.offAll(() => Homescreen());
                          },
                          child: Text(
                            "Back To Home",
                            style: redBoldTextStyle,
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

Widget packageContainerWidget(
  bool isActive,
  String textValue,
) {
  return Container(
    height: 5.h,
    width: 20.w,
    decoration: BoxDecoration(
      border: Border.all(color: isActive ? greenColor : greyColor),
      color: isActive == true
          ? greenColor.withOpacity(0.2)
          : greyColor.withOpacity(0.2),
      borderRadius: BorderRadius.circular(8),
    ),
    child: Center(
      child: Text(
        // "110 pellets",
        textValue,
        style: blackTextStyle.copyWith(
          fontSize: 14.sp,
        ),
      ),
    ),
  );
}

Widget dialogAddProduct() {
  return Padding(
    padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 5.h),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Image.asset(
          AppConstant.successIcon,
          width: 50.w,
        ),
        SizedBox(height: 3.h),
        Column(
          children: [
            Text(
              "BERHASIL",
              style: primaryBoldTextStyle.copyWith(fontSize: 18.sp),
            ),
            Text(
              "Berhasil menambahkan barang ke keranjang.",
              style: greyTextStyle.copyWith(fontSize: 14.sp),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextButton(
                  onPressed: () {
                    Get.back();
                    Get.to(() => CartPageMain(), preventDuplicates: false);
                  },
                  child: Text(
                    "Go To Cart",
                    style: greenBoldTextStyle,
                  ),
                ),
                TextButton(
                  onPressed: () {
                    Get.offAll(() => Homescreen());
                  },
                  child: Text(
                    "Back To Home",
                    style: redBoldTextStyle,
                  ),
                ),
              ],
            )
          ],
        ),
      ],
    ),
  );
}

// Widget ratingWidget() {
//   return Row(
//     crossAxisAlignment: CrossAxisAlignment.start,
//     mainAxisAlignment: MainAxisAlignment.center,
//     children: [
//       Column(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Row(
//             crossAxisAlignment: CrossAxisAlignment.center,
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Padding(
//                 padding: EdgeInsets.only(top: 1.h),
//                 child: Text(
//                   "4.4",
//                   style: blackBoldTextStyle.copyWith(
//                     fontSize: 33.sp,
//                   ),
//                 ),
//               ),
//               SizedBox(width: 2.w),
//               Icon(
//                 Icons.star,
//                 color: const Color(0xFFFFC000),
//                 size: 33.sp,
//               ),
//             ],
//           ),
//           SizedBox(height: 5.h),
//           SizedBox(
//             width: 30.w,
//             child: Text(
//               "923 Ratings and 257 Reviews",
//               style: greyTextStyle.copyWith(
//                 fontSize: 14.sp,
//               ),
//             ),
//           ),
//         ],
//       ),
//       SizedBox(width: 2.w),
//       CustomDivider(
//         type: DividerType.vertical,
//         length: 18.h,
//       ),
//       SizedBox(width: 2.w),
//       Column(
//         children: List.generate(5, (index) => ratingProgress()),
//       )
//     ],
//   );
// }

// Widget ratingProgress() {
//   return Row(
//     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//     children: [
//       Padding(
//         padding: EdgeInsets.only(top: 1.h),
//         child: Text(
//           '4',
//           style: greyTextStyle.copyWith(fontSize: 14.sp),
//         ),
//       ),
//       const Icon(
//         Icons.star,
//         color: Color(0xFFFFC000),
//       ),
//       SizedBox(width: 1.h),
//       const CustomLineProgress(),
//       SizedBox(width: 1.h),
//       Text(
//         '67%',
//         style: greyTextStyle.copyWith(fontSize: 14.sp),
//       ),
//     ],
//   );
// }

// Widget commentWidget() {
//   return Column(
//     children: [
//       Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Text(
//             "Lorem Hoffman",
//             style: blackTextStyle.copyWith(fontSize: 14.sp),
//           ),
//           Text(
//             "05- oct 2023",
//             style: greyTextStyle.copyWith(fontSize: 14.sp),
//           ),
//         ],
//       ),
//       Row(
//         children: [
//           const Icon(
//             Icons.star,
//             color: Color(0xFFFFC000),
//           ),
//           Text(
//             '4.2',
//             style: greyTextStyle.copyWith(fontSize: 14.sp),
//           ),
//         ],
//       ),
//       SizedBox(height: 1.h),
//       Text(
//         "Interdum et malesuada fames ac ante ipsum primis in faucibus. Morbi ut nisi odio. Nulla facilisi. Nunc risus massa, gravida id egestas ",
//         style: greyTextStyle.copyWith(fontSize: 14.sp),
//         textAlign: TextAlign.justify,
//       ),
//     ],
//   );
// }
