import 'package:ads_test/features/diabetes_care/view/diabetes_care_page.dart';
import 'package:ads_test/features/home/view/banner_home.dart';
import 'package:ads_test/features/home/widget/best_deals_slider.dart';
import 'package:ads_test/features/home/widget/top_categories_slider.dart';
import 'package:ads_test/features/home/widget/featured_brands_slider.dart';
import 'package:ads_test/utils/app_color.dart';
import 'package:ads_test/utils/app_constant.dart';
import 'package:ads_test/utils/app_textstyle.dart';
import 'package:ads_test/widgets/custom_textfield.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7FBFF),
      body: SingleChildScrollView(
        child: Stack(
          children: [
            // background
            Container(
              height: 30.h,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  const Color(0xFF1B75BC),
                  secondaryColor,
                ]),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(25.sp),
                  bottomRight: Radius.circular(25.sp),
                ),
              ),
            ),
            Column(
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 3.h),
                  child: headerHome(),
                ),
                // SizedBox(height: 1.h),
                searchBar(),
                SizedBox(height: 3.h),
                homeContent(),
              ],
            )
          ],
        ),
      ),
    );
  }
}

Widget headerHome() {
  return Padding(
    padding: EdgeInsets.only(top: 2.5.h),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            CircleAvatar(
              radius: 22.sp,
              child: Padding(
                padding: EdgeInsets.all(5.sp),
                child: Image.asset(AppConstant.googleIcon),
              ),
            ),
            IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.shopping_bag_outlined,
                size: 3.5.h,
                color: whiteColor,
              ),
            ),
          ],
        ),
        SizedBox(height: 3.h),
        Text(
          "Hi, Lorem",
          style: whiteTextStyle.copyWith(
              fontSize: 24.sp, fontWeight: FontWeight.w700),
        ),
        Text(
          "Welcome to UMKM",
          style: whiteTextStyle.copyWith(
              fontSize: 16.sp, fontWeight: FontWeight.w300),
        )
      ],
    ),
  );
}

Widget searchBar() {
  return Container(
    height: 7.h,
    width: 88.w,
    decoration: BoxDecoration(
        color: whiteColor,
        borderRadius: BorderRadius.circular(100),
        boxShadow: [
          BoxShadow(
            color: primaryColor.withOpacity(0.1),
            offset: const Offset(1, 1),
            blurRadius: 20,
          ),
        ]),
    child: Center(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 12.sp),
        child: CustomTextField(
          enabledBorder: false,
          prefixIcon: Icon(
            Icons.search,
            color: greyColor,
            size: 23.sp,
          ),
          fillColor: Colors.transparent,
          inline: true,
          hint: "Cari produk impian anda",
          hintStyle: TextStyle(fontSize: 16.sp, color: greyColor),
          // enabledBorder: ,
          // borderWidth: 0,
        ),
      ),
    ),
  );
}

Widget homeContent() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(
        padding: EdgeInsets.only(left: 5.w),
        child: Text(
          "Kategori",
          style: blackTextStyle.copyWith(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      // SizedBox(height: 3.h),
      const CategoriesSlider(),
      SizedBox(height: 2.5.h),
      const BannerHome(),
      SizedBox(height: 2.5.h),
      Padding(
        padding: EdgeInsets.only(left: 5.w, right: 2.w),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Produk Unggulan",
              style: blackTextStyle.copyWith(
                fontSize: 16.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            TextButton(
              onPressed: () {
                Get.to(() => const DiabetesCarePage());
              },
              child: Text(
                'More',
                style: greenTextStyle,
              ),
            ),
          ],
        ),
      ),
      const BestDealsSlider(),
      SizedBox(height: 2.5.h),
      Padding(
        padding: EdgeInsets.only(left: 5.w, right: 2.w),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Daftar UMKM",
              style: blackTextStyle.copyWith(
                fontSize: 16.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            TextButton(
              onPressed: () {},
              child: Text(
                'More',
                style: greenTextStyle,
              ),
            ),
          ],
        ),
      ),
      const FeaturedBrandsSlider(),
      SizedBox(height: 2.h),
    ],
  );
}
