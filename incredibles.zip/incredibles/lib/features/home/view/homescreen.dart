import 'package:ads_test/features/home/view/homepage.dart';
import 'package:ads_test/utils/app_color.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

class Homescreen extends StatefulWidget {
  const Homescreen({super.key});

  @override
  State<Homescreen> createState() => _HomescreenState();
}

class _HomescreenState extends State<Homescreen> {
  final selectedIndex = 0.obs;

  final List pages = [
    HomePage(),
    Container(),
    Container(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Container(
        height: 13.h,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(40),
              topRight: Radius.circular(40),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                offset: const Offset(0, 15),
                blurRadius: 30,
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.2),
                offset: const Offset(0, -10),
                blurRadius: 30,
              ),
            ]),
        child: ClipRRect(
          child: Obx(() => BottomNavigationBar(
                  showSelectedLabels: false,
                  type: BottomNavigationBarType.fixed,
                  backgroundColor: Colors.white,
                  elevation: 3,
                  landscapeLayout: BottomNavigationBarLandscapeLayout.spread,
                  showUnselectedLabels: false,
                  onTap: (value) => selectedIndex.value = value,
                  currentIndex: selectedIndex.value,
                  items: [
                    BottomNavigationBarItem(
                      icon: Icon(
                        Icons.home_outlined,
                        color: greyColor,
                        size: 22.sp,
                      ),
                      activeIcon: Icon(
                        Icons.home,
                        color: greenColor,
                        size: 22.sp,
                      ),
                      label: "",
                    ),
                    BottomNavigationBarItem(
                      icon: Container(
                        decoration: BoxDecoration(
                          color: primaryColor,
                          border: Border.all(color: primaryColor),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Icon(
                          Icons.add_box_outlined,
                          color: whiteColor,
                          size: 25.sp,
                        ),
                      ),
                      label: "",
                    ),
                    BottomNavigationBarItem(
                      icon: Icon(
                        Icons.person_outline,
                        color: greyColor,
                        size: 22.sp,
                      ),
                      activeIcon: Icon(
                        Icons.person,
                        color: greenColor,
                        size: 22.sp,
                      ),
                      label: "",
                    ),
                  ])),
        ),
      ),
      body: Obx(() => pages[selectedIndex.value]),
    );
  }
}
