import 'package:ads_test/features/diabetes_care/view/detail_product.dart';
import 'package:ads_test/features/home/widget/best_deals_contents.dart';
import 'package:ads_test/widgets/custom_product_card.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

class BestDealsSlider extends StatelessWidget {
  const BestDealsSlider({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 38.5.h,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 2.w),
        child: ListView.builder(
          itemCount: bestDealsList.length,
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) {
            return Row(
              children: [
                SizedBox(width: 1.w),
                GestureDetector(
                  onTap: () => Get.to(() => DetailProduct()),
                  child: CustomProductCard(
                    image: bestDealsList[index].image,
                    titleProduct: bestDealsList[index].titleProduct,
                    priceProduct: bestDealsList[index].priceProduct,
                    rating: bestDealsList[index].rating,
                  ),
                ),
                SizedBox(width: 1.w),
              ],
            );
          },
        ),
      ),
    );
  }
}
