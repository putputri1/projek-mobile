import 'package:ads_test/utils/app_color.dart';
import 'package:ads_test/utils/app_textstyle.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class CategoryCard extends StatelessWidget {
  const CategoryCard({
    super.key,
    this.linearColors,
    this.catTitle,
    this.icon,
  });

  final List<Color>? linearColors;
  final String? catTitle;
  final String? icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(left: 3.w, right: 2.w),
      height: 8.h,
      width: 40.w,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
              colors: linearColors ??
                  [
                    secondaryColor,
                    secondaryColor.withOpacity(0.2),
                  ]),
          boxShadow: [
            BoxShadow(
              color: primaryColor.withOpacity(0.2),
              blurRadius: 10,
              offset: Offset(0, 3),
            )
          ]),
      child: Row(
        children: [
          Container(
            height: 5.h,
            width: 10.w,
            decoration: BoxDecoration(
              color: linearColors?[1].withOpacity(0.5),
              border: Border.all(color: whiteColor, width: 2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Image.asset(icon ?? '', scale: 1.w),
          ),
          SizedBox(width: 2.w),
          Expanded(
            child: Text(
              catTitle ?? '',
              style: whiteTextStyle.copyWith(fontSize: 15.sp, shadows: [
                Shadow(
                  color: blackColor.withOpacity(0.2),
                  blurRadius: 10,
                  offset: Offset(0, 2),
                )
              ]),
            ),
          )
        ],
      ),
    );

    // Padding(
    //   padding: EdgeInsets.symmetric(vertical: 2.h),
    //   child: Column(
    //     crossAxisAlignment: CrossAxisAlignment.center,
    //     mainAxisAlignment: MainAxisAlignment.start,
    //     children: [
    //       Container(
    //         height: 6.h,
    //         width: 12.w,
    //         decoration: BoxDecoration(
    //           gradient: LinearGradient(
    //               begin: Alignment.topCenter,
    //               end: Alignment.bottomCenter,
    //               colors: linearColors!),
    //           borderRadius: BorderRadius.circular(100),
    //         ),
    //         child: Image.asset(
    //           icon!,
    //           scale: 1.w,
    //         ),
    //       ),
    //       SizedBox(height: 1.h),
    //       SizedBox(
    //         width: 18.w,
    //         child: Text(
    //           catTitle!,
    //           style: blackTextStyle.copyWith(fontSize: 14.sp),
    //           textAlign: TextAlign.center,
    //           maxLines: 2,
    //         ),
    //       )
    //     ],
    //   ),
    // );
  }
}
