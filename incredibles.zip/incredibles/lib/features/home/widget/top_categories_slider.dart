import 'package:ads_test/features/home/widget/category_card.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class CategoriesSlider extends StatelessWidget {
  const CategoriesSlider({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        // direction: Axis.horizontal,
        children: List.generate(
          categoryList.length,
          (index) {
            return Padding(
              padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 3.w),
              child: CategoryCard(
                catTitle: categoryList[index].catTitle,
                icon: categoryList[index].icon,
                linearColors: categoryList[index].linearColors,
              ),
            );
          },
        ),
      ),
    );

    //     SizedBox(
    //   height: 15.h,
    //   child: ListView.builder(
    //     scrollDirection: Axis.horizontal,
    //     itemCount: categoryList.length,
    //     itemBuilder: (context, index) {
    //       return CategoryCard(
    //         catTitle: categoryList[index].catTitle,
    //         icon: categoryList[index].icon,
    //         linearColors: categoryList[index].linearColors,
    //       );
    //     },
    //   ),
    // );
  }
}

class TopCategory {
  List<Color>? linearColors;
  String? catTitle;
  String? icon;

  TopCategory({
    this.catTitle,
    this.icon,
    this.linearColors,
  });
}

List<TopCategory> categoryList = [
  TopCategory(
    catTitle: "Kebutuhan Pokok",
    icon: 'assets/icons/dental_icon.png',
    linearColors: [
      Color(0xFFFF9598),
      Color(0xFFFF70A7),
      // const Color(0xFF1B75BC),
      // secondaryColor,
    ],
  ),
  TopCategory(
    catTitle: "Makanan dan Minuman",
    icon: 'assets/icons/wellness_icon.png',
    linearColors: [
      Color(0XFF19E5A5),
      Color(0XFF15BD92),
      // const Color(0xFF1B75BC),
      // secondaryColor,
    ],
  ),
];
