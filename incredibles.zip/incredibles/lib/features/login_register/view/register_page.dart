import 'package:ads_test/features/home/view/homescreen.dart';
import 'package:ads_test/features/login_register/view/login_page.dart';
import 'package:ads_test/utils/app_color.dart';
import 'package:ads_test/utils/app_textstyle.dart';
import 'package:ads_test/widgets/custom_button.dart';
import 'package:ads_test/widgets/custom_textfield.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

class RegisterPage extends StatelessWidget {
  const RegisterPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: const SizedBox(),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 0.h),
            child: Column(
              // crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        "Buat akun baru anda",
                        style: primaryBoldTextStyle.copyWith(
                          fontSize: 24.sp,
                        ),
                      ),
                    ),
                    SizedBox(height: 3.h),
                    formField(),
                    SizedBox(height: 8.h),
                    CustomButton(
                      elevation: 8,
                      width: MediaQuery.of(context).size.width,
                      height: 6.h,
                      borderColor: primaryColor,
                      borderWidth: 0,
                      textStyle: whiteTextStyle.copyWith(
                          fontSize: 16.sp, fontWeight: FontWeight.w700),
                      text: 'Daftar'.toUpperCase(),
                      onPressed: () {
                        Get.to(const Homescreen());
                      },
                      backgroundColor: primaryColor,
                    ),
                  ],
                ),
                SizedBox(height: 2.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.arrow_back_ios,
                      size: 13.sp,
                      color: greyColor,
                    ),
                    TextButton(
                      onPressed: () {
                        Get.to(const LoginPage());
                      },
                      child: Text(
                        "Sudah punya akun? Masuk",
                        style: greyTextStyle.copyWith(
                          fontSize: 15.sp,
                        ),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ));
  }
}

Widget formField() {
  return Column(
    children: [
      CustomTextField(
        label: "Nama Lengkap",
        labelTextStyle: greyTextStyle,
        inline: true,
        fillColor: Colors.transparent,
        // hint: "Nama Lengkap",
        hintStyle: TextStyle(
            fontSize: 15.sp, color: greyColor, fontWeight: FontWeight.w400),
      ),
      SizedBox(height: 2.h),
      CustomTextField(
        label: "Nomor Telepon",
        labelTextStyle: greyTextStyle,
        inline: true,
        fillColor: Colors.transparent,
        // hint: "Nama Lengkap",
        hintStyle: TextStyle(
            fontSize: 15.sp, color: greyColor, fontWeight: FontWeight.w400),
      ),
      SizedBox(height: 2.h),
      CustomTextField(
        label: "Tipe Akun",
        labelTextStyle: greyTextStyle,
        inline: true,
        fillColor: Colors.transparent,
        // hint: "Nama Lengkap",
        hintStyle: TextStyle(
            fontSize: 15.sp, color: greyColor, fontWeight: FontWeight.w400),
      ),
      SizedBox(height: 2.h),
      CustomTextField(
        label: "Email",
        labelTextStyle: greyTextStyle,
        inline: true,
        fillColor: Colors.transparent,
        // hint: "Nama Lengkap",
        hintStyle: TextStyle(
            fontSize: 15.sp, color: greyColor, fontWeight: FontWeight.w400),
      ),
      SizedBox(height: 2.h),
      CustomTextField(
        label: "Password",
        labelTextStyle: greyTextStyle,
        inline: true,
        fillColor: Colors.transparent,
        // hint: "Password",
        isObscure: true,
        suffixIcon: IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.visibility_off_rounded,
              color: primaryColor.withOpacity(0.5),
            )),
        hintStyle: TextStyle(
            fontSize: 15.sp, color: greyColor, fontWeight: FontWeight.w400),
      ),
    ],
  );
}
