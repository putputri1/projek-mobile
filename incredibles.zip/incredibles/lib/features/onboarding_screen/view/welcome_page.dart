import 'package:ads_test/features/login_register/view/login_page.dart';
import 'package:ads_test/utils/app_color.dart';
import 'package:ads_test/utils/app_constant.dart';
import 'package:ads_test/utils/app_textstyle.dart';
import 'package:ads_test/widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              color: whiteColor,
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: 10.w,
                  vertical: 5.h,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      'assets/images/intro3.png',
                      width: 75.w,
                    ),
                    SizedBox(height: 3.h),
                    Column(
                      children: [
                        SizedBox(
                          width: 60.w,
                          child: Text(
                            "Welcome to UMKM",
                            textAlign: TextAlign.center,
                            style: primaryTextStyle.copyWith(
                              fontSize: 20.sp,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        SizedBox(height: 2.h),
                        SizedBox(
                          width: 70.w,
                          child: Text(
                            "Kami mengumpulkan produk berkualitas dari UMKM",
                            textAlign: TextAlign.center,
                            style: greyTextStyle.copyWith(fontSize: 16.sp),
                          ),
                        ),
                        SizedBox(height: 4.h),
                        CustomButton(
                          elevation: 5,
                          width: 70.w,
                          height: 6.h,
                          borderColor: primaryColor,
                          borderWidth: 0,
                          textStyle: whiteBoldTextStyle,
                          text: 'DAFTAR DENGAN EMAIL'.toUpperCase(),
                          onPressed: () {},
                          backgroundColor: primaryColor,
                        ),
                        SizedBox(height: 1.h),
                        BtnLoginFb(
                          onPressed: () {},
                        ),
                        SizedBox(height: 1.h),
                        BtnLoginGoogle(
                          onPressed: () {},
                        ),
                        TextButton(
                          onPressed: () {
                            Get.to(() => const LoginPage());
                          },
                          child: Text(
                            "Masuk",
                            style: greyTextStyle.copyWith(fontSize: 15.sp),
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}

class BtnLoginGoogle extends StatelessWidget {
  const BtnLoginGoogle({
    super.key,
    required this.onPressed,
  });

  final Function() onPressed;

  @override
  Widget build(BuildContext context) {
    return CustomButton(
      width: 70.w,
      height: 6.h,
      borderColor: greyColor,
      borderWidth: 1,
      textStyle: blackTextStyle.copyWith(fontSize: 15.sp),
      text: 'Continue with Gmail'.toUpperCase(),
      onPressed: () {},
      prefixIcon: Image.asset(
        AppConstant.googleIcon,
        width: 18.sp,
      ),
      backgroundColor: whiteColor,
    );
  }
}

class BtnLoginFb extends StatelessWidget {
  const BtnLoginFb({
    super.key,
    required this.onPressed,
  });

  final Function() onPressed;

  @override
  Widget build(BuildContext context) {
    return CustomButton(
      width: 70.w,
      height: 6.h,
      borderColor: greyColor,
      borderWidth: 1,
      textStyle: blackTextStyle.copyWith(fontSize: 15.sp),
      text: 'Continue with facebook'.toUpperCase(),
      onPressed: onPressed,
      prefixIcon: Image.asset(
        AppConstant.fbIcon,
        width: 18.sp,
      ),
      backgroundColor: whiteColor,
    );
  }
}
