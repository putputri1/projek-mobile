import 'package:flutter/material.dart';

Color primaryColor = const Color.fromARGB(255, 8, 39, 67);
Color secondaryColor = const Color(0xFF00AAF5);
Color textOnPrimary = blackColor;

// basic colors
Color semiWhite = const Color(0XFFF7FBFF);
Color greyColor = const Color(0XFFAEAFB1);
Color lightGreyColor = const Color(0XFFEDEDED);
Color darkGreyColor = const Color(0XFF8B8B8B);
Color blackColor = Colors.black;
Color whiteColor = Colors.white;
Color redColor = const Color(0XFFE71515);
Color greenColor = const Color(0xFF00A59B);
Color orangeColor = const Color(0xFFE27C00);
