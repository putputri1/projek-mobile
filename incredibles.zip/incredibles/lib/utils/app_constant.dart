class AppConstant {
  static String successIcon = 'assets/icons/success_icon.png';
  static String fbIcon = 'assets/icons/fb_icon.png';
  static String googleIcon = 'assets/icons/google_icon.png';
  static String bgBanner = 'assets/images/bg_banner.png';
  static String splashLogo = 'assets/icons/splash_logo.png';
}
