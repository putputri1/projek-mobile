import 'package:ads_test/features/home/view/homescreen.dart';
import 'package:ads_test/utils/app_color.dart';
import 'package:ads_test/utils/app_constant.dart';
import 'package:ads_test/utils/app_textstyle.dart';
import 'package:ads_test/widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

class SuccessScreen extends StatelessWidget {
  const SuccessScreen({super.key, required this.invoice});

  final String invoice;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Center(
        child: Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  AppConstant.successIcon,
                  width: 60.w,
                ),
                Padding(
                  padding: EdgeInsets.only(top: 8.h),
                  child: Text(
                    "Terima Kasih",
                    style: primaryBoldTextStyle.copyWith(
                      fontSize: 24.sp,
                    ),
                  ),
                ),
                Padding(
                  padding:
                      EdgeInsets.symmetric(vertical: 2.h, horizontal: 10.w),
                  child: Text.rich(
                    TextSpan(
                      text: 'Your Order will be delivered with invoice ',
                      style: greyTextStyle.copyWith(fontSize: 16.sp),
                      children: [
                        TextSpan(
                          // text: '#INV20240817',
                          text: invoice,
                          style: primaryBoldTextStyle,
                        ),
                        TextSpan(
                          text:
                              '. You can track the delivery in the order section.',
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
            Positioned(
              bottom: 5.h,
              left: 5.w,
              right: 5.w,
              child: CustomButton(
                elevation: 8,
                width: MediaQuery.of(context).size.width,
                height: 6.8.h,
                borderColor: primaryColor,
                borderWidth: 0,
                textStyle: whiteTextStyle.copyWith(
                    fontSize: 16.sp, fontWeight: FontWeight.w700),
                text: 'Kembali ke Beranda',
                onPressed: () {
                  Get.offAll(() => Homescreen());
                },
                backgroundColor: primaryColor,
              ),
            )
          ],
        ),
      )),
    );
  }
}
