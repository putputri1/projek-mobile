import 'package:ads_test/utils/app_color.dart';
import 'package:ads_test/utils/app_textstyle.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class CustomCounter extends StatelessWidget {
  const CustomCounter({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 5.h,
      width: 27.w,
      decoration: BoxDecoration(
          color: greyColor, borderRadius: BorderRadius.circular(100)),
      child: Row(
        children: [
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.remove_circle_rounded,
              size: 22.sp,
              color: const Color(0xffDFE3FF),
            ),
          ),
          Text(
            "1",
            style: blackTextStyle.copyWith(fontSize: 14.sp),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.add_circle_rounded,
              size: 22.sp,
              color: Color(0xFFA0ABFF),
            ),
          ),
        ],
      ),
    );
  }
}
