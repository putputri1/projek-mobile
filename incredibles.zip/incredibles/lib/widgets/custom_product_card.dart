import 'package:ads_test/utils/app_color.dart';
import 'package:ads_test/utils/app_textstyle.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class CustomProductCard extends StatelessWidget {
  const CustomProductCard({
    super.key,
    this.height,
    this.width,
    required this.image,
    this.imageBackgroundColor,
    required this.rating,
    required this.priceProduct,
    required this.titleProduct,
    this.borderColor,
    this.badge,
    this.imageHeight,
  });

  final double? height;
  final double? width;
  final double? imageHeight;
  final Color? imageBackgroundColor;
  final String image;
  final String titleProduct;
  final String priceProduct;
  final String rating;
  final Color? borderColor;
  final Widget? badge;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height ?? 35.h,
      width: width ?? 42.w,
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            spreadRadius: 0.2,
            blurRadius: 10,
            offset: const Offset(5, 5),
            color: primaryColor.withOpacity(0.1),
          )
        ],
        color: whiteColor,
        border: Border.all(color: borderColor ?? Colors.transparent),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Stack(
        children: [
          Column(
            children: [
              Container(
                height: imageHeight ?? 21.h,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  color: imageBackgroundColor ?? const Color(0xFFEEEEF0),
                  // border: Border.all(color: blackColor),
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10)),
                ),
                child: Image.asset(image),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.5.h),
                child: Text(
                  titleProduct,
                  style: blackTextStyle.copyWith(
                    fontSize: 15.sp,
                  ),
                ),
              ),
              // SizedBox(height: 1.h),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 3.w),
                    child: Text(
                      priceProduct,
                      style: blackBoldTextStyle.copyWith(fontSize: 17.sp),
                    ),
                  ),
                ],
              ),
            ],
          ),
          badge ?? SizedBox(),
        ],
      ),
    );
  }
}
